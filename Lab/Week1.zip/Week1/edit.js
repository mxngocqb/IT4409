// let data= {}
// const submitBtn = document.querySelector('.submit')
// submitBtn.onclick = () => {
//     data.name = document.querySelector('.name').innerText
//     data.sex = document.querySelector('.sex').innerText
//     data.religion = document.querySelector('.religion').innerText
//     data.highschoolName = document.querySelector('.highschool-name').innerText
//     data.phoneNumber = document.querySelector('.phone-number').innerText
//     data.household = document.querySelector('.household').innerText
//     data.email = document.querySelector('.email').innerText
//     data.ethnicity = document.querySelector('.ethnicity').innerText
//     data.granduatedYear = document.querySelector('.granduated-year').innerText
//     data.address = document.querySelector('.address').innerText
//     data.idCardNumber = document.querySelector('.id-number').innerText
//     data.issuedBy = document.querySelector('.issued-by').innerText
//     data.father = {}
//     data.father.name = document.querySelector('.father-name').innerText
//     data.father.dob = document.querySelector('.father-dob').innerText
//     data.father.job = document.querySelector('.father-job').innerText
//     data.father.phoneNumber = document.querySelector('.father-phone-number').innerText
//     data.father.email = document.querySelector('.father-email').innerText
//     data.mother = {}
//     data.mother.name = document.querySelector('.mother-name').innerText
//     data.mother.dob = document.querySelector('.mother-dob').innerText
//     data.mother.job = document.querySelector('.mother-job').innerText
//     data.mother.phoneNumber = document.querySelector('.mother-phone-number').innerText
//     data.mother.email = document.querySelector('.mother-email').innerText
//     localStorage.setItem('data', JSON.stringify(data))
// }